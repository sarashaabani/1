﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace computer1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = int.Parse(textBox1.Text);
            int f1 = 0, f2 = 1, f3=1;
            if (n == 1)
                MessageBox.Show(f1.ToString());
            if (n == 2)
                MessageBox.Show(f2.ToString());
            else
            {
                for (int i = 3;i<= n; i++)
                {
                    f3 = f1 + f2;
                    f1 = f2;
                    f2 = f3;      
                }
                MessageBox.Show(f3.ToString());
            }
           
         }
    }
}
